// Synthesises the SFX kit (6 short, soft, UI-style sounds) as 16-bit mono WAVs into public/sfx/.
// Deterministic (seeded noise). Run: node scripts/gen-sfx.mjs
import fs from "node:fs";

const SR = 44100;
const outDir = new URL("../public/sfx/", import.meta.url);
fs.mkdirSync(outDir, { recursive: true });

let seed = 20261118;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return (seed / 4294967296) * 2 - 1;
};

const make = (sec) => new Float32Array(Math.round(sec * SR));

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) {
    y += a * (x[i] - y);
    x[i] = y;
  }
  return x;
};
const highpass = (x, fc) => {
  const l = Float32Array.from(x);
  lowpass(l, fc);
  for (let i = 0; i < x.length; i++) x[i] -= l[i];
  return x;
};

// very small feed-forward "room": three short taps
const room = (x, mix = 0.1) => {
  const y = Float32Array.from(x);
  for (const [d, g] of [[0.019, 0.4], [0.031, 0.3], [0.047, 0.2]]) {
    const dl = Math.round(d * SR);
    for (let i = dl; i < x.length; i++) y[i] += mix * g * x[i - dl] * 4;
  }
  return y;
};

const finish = (x, { fadeOut = 0.03 } = {}) => {
  const n = Math.round(fadeOut * SR);
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

// ---- sounds ---------------------------------------------------------------
const pop = () => {
  const x = make(0.26);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 170 + 430 * Math.exp(-t / 0.028); // fast downward pitch
    ph += (2 * Math.PI * f) / SR;
    const a = Math.min(1, t / 0.004) * Math.exp(-t / 0.055);
    x[i] = Math.sin(ph) * a + 0.15 * Math.sin(2 * ph) * a;
  }
  lowpass(x, 4200);
  return finish(room(x, 0.08));
};

const click = () => {
  const x = make(0.14);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = rnd() * Math.exp(-t / 0.007) + 0.35 * Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t / 0.01);
  }
  highpass(x, 1600);
  lowpass(x, 7000);
  return finish(room(x, 0.06), { fadeOut: 0.02 });
};

const tick = () => {
  const x = make(0.09);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = (0.6 * rnd() + Math.sin(2 * Math.PI * 1150 * t)) * Math.exp(-t / 0.006) * Math.min(1, t / 0.0015);
  }
  highpass(x, 700);
  lowpass(x, 5200);
  return finish(x, { fadeOut: 0.02 });
};

const whoosh = () => {
  const n = Math.round(0.72 * SR);
  const x = new Float32Array(n);
  let low = 0, band = 0;
  const q = 0.85;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const fc = 260 + 2600 * Math.pow(t, 1.6); // band-pass sweep upward
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    low += f * band;
    const high = rnd() - low - q * band;
    band += f * high;
    const w = Math.pow(Math.sin(Math.PI * Math.pow(t, 0.75)), 2); // fade in / out
    x[i] = band * w;
  }
  lowpass(x, 5200);
  return finish(room(x, 0.06), { fadeOut: 0.05 });
};

const chime = () => {
  const x = make(0.5);
  const partials = [[880, 1, 0.16], [1318.5, 0.5, 0.13], [1760, 0.28, 0.1], [2637, 0.1, 0.07]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [f, a, d] of partials) s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / d);
    x[i] = s * Math.min(1, t / 0.006);
  }
  lowpass(x, 6500);
  return finish(room(x, 0.12), { fadeOut: 0.06 });
};

const thud = () => {
  const x = make(0.36);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 46 + 70 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * Math.min(1, t / 0.005) * Math.exp(-t / 0.09) + 0.08 * rnd() * Math.exp(-t / 0.015);
  }
  lowpass(x, 520);
  return finish(x, { fadeOut: 0.05 });
};

// ---- write + verify -------------------------------------------------------
const rms = (x) => Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length);
const peak = (x) => x.reduce((m, v) => Math.max(m, Math.abs(v)), 0);

const writeWav = (name, x) => {
  // level-match: RMS target, with a peak ceiling of 0.8 (no clipping)
  const target = 0.12;
  let g = target / rms(x);
  if (peak(x) * g > 0.8) g = 0.8 / peak(x);
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVE", 8);
  pcm.write("fmt ", 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  let clipped = 0, pk = 0, sq = 0;
  for (let i = 0; i < x.length; i++) {
    const v = x[i] * g;
    if (Math.abs(v) >= 0.999) clipped++;
    pk = Math.max(pk, Math.abs(v)); sq += v * v;
    pcm.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2);
  }
  fs.writeFileSync(new URL(`${name}.wav`, outDir), pcm);
  const db = (v) => (20 * Math.log10(v)).toFixed(1);
  console.log(
    `${name.padEnd(7)} ${(x.length / SR).toFixed(2)}s  peak ${pk.toFixed(2)} (${db(pk)} dBFS)  rms ${db(Math.sqrt(sq / x.length))} dBFS  clipped ${clipped}`
  );
};

for (const [name, fn] of Object.entries({ pop, click, tick, whoosh, chime, thud })) writeWav(name, fn());
