// Preview / render switches.
export const CONFIG = {
  /** Play public/voiceover.mp3 in Remotion Studio (skipped silently if the file is missing). */
  voiceoverInStudio: true,
  /** Mix public/voiceover.mp3 into a rendered MP4. Default OFF: the render carries SFX only. */
  voiceoverInRender: false,
  /** Master switch for the SFX layer. */
  sfx: true,
} as const;
