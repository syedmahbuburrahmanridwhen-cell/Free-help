// theme.ts — single source of truth: colours, fonts, easing, spring presets, shape language.
// Scheme 1: "রয়্যাল নেভি ও ক্রিমসন". No component may inline a colour, easing or spring.
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: reliable Bengali conjuncts (যুক্তাক্ষর). 700 is its heaviest weight.
const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

/** hex (#rrggbb) + alpha -> rgba() string */
export const A = (hex: string, alpha: number): string => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
};

export const theme = {
  colors: {
    bg: "#0B1530",
    bgAlt: "#101D40",
    surface: "#16254D", // lifted navy, derived from bg
    surfaceHi: "#253B75", // lifted navy for map regions
    hero: "#C8102E", // THE hero colour — used sparingly
    accent: "#E8B04A",
    text: "#F5F1E8",
    textDim: "#A8B0C6", // text, pulled toward bg
    black: "#000000",
  },
  fonts: { display: fontFamily, body: fontFamily },
  weight: { display: 700, strong: 600, body: 500 },
  radius: { card: 32, chip: 20, pill: 999 },
  // Bengali has tall matras above/below the line: never go below ~1.3.
  lineHeight: 1.38,
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    count: { damping: 24, stiffness: 120, mass: 0.9 }, // counters: settles in ~1s, no overshoot
  },
  motion: { enter: 18, exit: 10 },
  shadow: {
    card: "0 36px 70px -28px rgba(0, 0, 0, 0.7)",
  },
} as const;

export type SpringKey = keyof typeof theme.spring;
