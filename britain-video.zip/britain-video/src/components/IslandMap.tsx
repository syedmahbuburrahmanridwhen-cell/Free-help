// IslandMap — the video's one recurring visual metaphor: a stylised (not survey-accurate) map that
// is assembled, split, joined and re-split as the story moves. Drawn in code; no external assets.
import React from "react";
import { theme, A } from "../theme";

export type RegionKey = "scotland" | "england" | "wales" | "ni" | "ireland";

export const REGION_PTS: Record<RegionKey, number[][]> = {
  scotland: [[235,22],[262,34],[290,24],[302,52],[286,74],[306,98],[284,124],[296,150],[270,176],[278,204],[262,236],[232,230],[205,240],[188,214],[165,200],[170,176],[148,160],[160,138],[140,118],[152,92],[138,70],[165,58],[190,64],[206,44],[222,50]],
  england: [[205,240],[232,230],[262,236],[282,250],[300,278],[296,304],[322,330],[344,350],[350,382],[332,404],[346,430],[336,462],[312,478],[284,490],[250,500],[214,512],[186,524],[150,538],[118,552],[86,566],[66,556],[84,534],[112,520],[132,502],[150,478],[170,458],[192,444],[196,418],[196,392],[202,368],[204,340],[214,312],[208,286],[216,262]],
  wales: [[204,340],[172,334],[130,348],[104,374],[138,392],[122,418],[150,444],[192,444],[196,418],[196,392],[202,368]],
  ni: [[22,232],[62,216],[100,226],[112,256],[104,290],[64,296],[34,286],[14,262]],
  ireland: [[14,262],[34,286],[64,296],[104,290],[110,320],[104,352],[96,380],[84,408],[54,420],[26,402],[6,364],[16,328],[-2,298]],
};

const toD = (pts: number[][]) => "M" + pts.map((p) => p.join(",")).join(" L") + " Z";
export const REGION_D = Object.fromEntries(
  (Object.keys(REGION_PTS) as RegionKey[]).map((k) => [k, toD(REGION_PTS[k])])
) as Record<RegionKey, string>;

export const MAP_W = 440;
export const MAP_H = 600;
export type View = [number, number, number, number];
export const FULL: View = [0, 0, MAP_W, MAP_H];

/** tight view box around one or more regions */
export const viewOf = (keys: RegionKey[], pad = 14): View => {
  const xs: number[] = [];
  const ys: number[] = [];
  keys.forEach((k) => REGION_PTS[k].forEach(([x, y]) => (xs.push(x), ys.push(y))));
  const x0 = Math.min(...xs) - pad, y0 = Math.min(...ys) - pad;
  return [x0, y0, Math.max(...xs) + pad - x0, Math.max(...ys) + pad - y0];
};

/** map-space point -> page px, for a map drawn at height h with its top-left at (left, top) */
export const mapPt = (h: number, left: number, top: number, x: number, y: number, view: View = FULL): [number, number] => {
  const s = h / view[3];
  return [left + (x - view[0]) * s, top + (y - view[1]) * s];
};

/** point-in-polygon (for scattering dots inside the land) */
export const inside = (x: number, y: number, pts: number[][]) => {
  let c = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i];
    const [xj, yj] = pts[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
};

export type RegionStyle = {
  dx?: number;
  dy?: number;
  rot?: number;
  scale?: number;
  op?: number;
  fill?: string;
  stroke?: string;
  strokeW?: number;
  /** 0..1 outline draw-on */
  draw?: number;
  /** 0..1 fill opacity multiplier */
  fillOp?: number;
  glow?: string;
  dashed?: boolean;
};

const ORDER: RegionKey[] = ["ireland", "ni", "scotland", "england", "wales"];

export const IslandMap: React.FC<{
  h: number;
  regions: Partial<Record<RegionKey, RegionStyle>>;
  view?: View;
  style?: React.CSSProperties;
}> = ({ h, regions, view = FULL, style }) => {
  const c = theme.colors;
  return (
    <svg
      width={(h * view[2]) / view[3]}
      height={h}
      viewBox={view.join(" ")}
      style={{ overflow: "visible", ...style }}
    >
      {ORDER.map((k) => {
        const r = regions[k];
        if (!r) return null;
        const draw = r.draw ?? 1;
        return (
          <g
            key={k}
            style={{
              transform: `translate(${r.dx ?? 0}px, ${r.dy ?? 0}px) rotate(${r.rot ?? 0}deg) scale(${r.scale ?? 1})`,
              transformBox: "fill-box",
              transformOrigin: "center",
              opacity: r.op ?? 1,
              filter: r.glow ? `drop-shadow(0 0 22px ${r.glow})` : undefined,
            }}
          >
            <path d={REGION_D[k]} fill={r.fill ?? c.surfaceHi} fillOpacity={(r.fillOp ?? 1) * (draw >= 1 ? 1 : draw * 0.2)} />
            <path
              d={REGION_D[k]}
              pathLength={1}
              fill="none"
              stroke={r.stroke ?? A(c.text, 0.55)}
              strokeWidth={r.strokeW ?? 2.5}
              strokeLinejoin="round"
              strokeDasharray={r.dashed ? "0.02 0.014" : 1}
              strokeDashoffset={r.dashed ? 0 : 1 - draw}
            />
          </g>
        );
      })}
    </svg>
  );
};

/** coarse centre of each region in map units — for pins and labels */
export const REGION_CENTER: Record<RegionKey, [number, number]> = {
  scotland: [220, 140],
  england: [260, 390],
  wales: [150, 392],
  ni: [62, 258],
  ireland: [56, 352],
};
