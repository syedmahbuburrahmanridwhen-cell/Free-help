// kit.tsx — shared building blocks. Every entrance animates 2–3 properties, uses spring/bezier,
// and never splits Bengali text below word level (words split on spaces only, letterSpacing 0).
import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, A, SpringKey } from "../theme";

type Dir = "up" | "down" | "left" | "right" | "none";
const offset = (d: Dir, n: number): [number, number] =>
  d === "up" ? [0, n] : d === "down" ? [0, -n] : d === "left" ? [n, 0] : d === "right" ? [-n, 0] : [0, 0];

export const useSpring = (at: number, cfg: SpringKey = "smooth") => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - at, fps, config: theme.spring[cfg] });
};

/** clamped, eased 0..1 progress between two local frames */
export const useProgress = (from: number, to: number, ease: (n: number) => number = theme.ease.out) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [from, to], [0, 1], {
    easing: ease,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

/** fade + travel + scale entrance */
export const Pop: React.FC<{
  at: number;
  dir?: Dir;
  dist?: number;
  from?: number;
  cfg?: SpringKey;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ at, dir = "up", dist = 36, from = 0.92, cfg = "smooth", style, children }) => {
  const p = useSpring(at, cfg);
  const [dx, dy] = offset(dir, dist);
  const o = interpolate(p, [0, 0.6], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${(1 - p) * dx}px, ${(1 - p) * dy}px) scale(${from + (1 - from) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** slow idle breathing for anything that stays on screen */
export const Float: React.FC<{ amp?: number; speed?: number; phase?: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  amp = 6,
  speed = 34,
  phase = 0,
  style,
  children,
}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{ transform: `translateY(${Math.sin(frame / speed + phase) * amp}px)`, ...style }}>{children}</div>
  );
};

/** word-by-word staggered text (spaces only). `hi` = indices coloured with the accent. */
export const Words: React.FC<{
  text: string;
  at: number;
  size: number;
  per?: number;
  color?: string;
  hi?: number[];
  hiColor?: string;
  weight?: number;
  align?: "left" | "center";
  style?: React.CSSProperties;
}> = ({ text, at, size, per = 4, color = theme.colors.text, hi = [], hiColor = theme.colors.accent, weight = theme.weight.display, align = "left", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.04),
        justifyContent: align === "center" ? "center" : "flex-start",
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: theme.lineHeight,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - at - i * per, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: interpolate(p, [0, 0.6], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
              transform: `translateY(${(1 - p) * size * 0.38}px) scale(${0.92 + 0.08 * p})`,
              color: hi.includes(i) ? hiColor : color,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** counter roll — only ever used for numbers that appear in the script */
export const Counter: React.FC<{
  to: number;
  at: number;
  size: number;
  from?: number;
  color?: string;
  suffix?: string;
  style?: React.CSSProperties;
}> = ({ to, at, size, from, color = theme.colors.accent, suffix = "", style }) => {
  const p = useSpring(at, "count");
  const start = from ?? Math.max(0, to - 320);
  const v = p > 0.995 ? to : Math.round(interpolate(p, [0, 1], [start, to], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  const o = interpolate(p, [0, 0.15], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <span
      style={{
        fontFamily: theme.fonts.display,
        fontWeight: theme.weight.display,
        fontSize: size,
        lineHeight: 1.1,
        letterSpacing: 0,
        fontVariantNumeric: "tabular-nums",
        color,
        opacity: o,
        ...style,
      }}
    >
      {v}
      {suffix}
    </span>
  );
};

/** glass card */
export const Glass: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode }> = ({ style, children }) => (
  <div
    style={{
      background: `linear-gradient(150deg, ${A(theme.colors.text, 0.11)}, ${A(theme.colors.text, 0.035)})`,
      border: `1.5px solid ${A(theme.colors.text, 0.16)}`,
      borderRadius: theme.radius.card,
      backdropFilter: "blur(18px)",
      boxShadow: theme.shadow.card,
      boxSizing: "border-box",
      ...style,
    }}
  >
    {children}
  </div>
);

/** small label chip */
export const Pill: React.FC<{
  tone?: "accent" | "hero" | "dim";
  size?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ tone = "accent", size = 30, style, children }) => {
  const c = theme.colors;
  const map = {
    accent: { bg: A(c.accent, 0.14), fg: c.accent, bd: A(c.accent, 0.5) },
    hero: { bg: c.hero, fg: c.text, bd: c.hero },
    dim: { bg: A(c.text, 0.07), fg: c.textDim, bd: A(c.text, 0.18) },
  }[tone];
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        padding: `${Math.round(size * 0.2)}px ${Math.round(size * 0.7)}px`,
        borderRadius: theme.radius.pill,
        background: map.bg,
        color: map.fg,
        border: `1.5px solid ${map.bd}`,
        fontFamily: theme.fonts.body,
        fontWeight: theme.weight.strong,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** keyword with a gold highlight sweep behind it */
export const Sweep: React.FC<{ at: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ at, children, style }) => {
  const p = useProgress(at, at + 14);
  return (
    <span style={{ position: "relative", display: "inline-block", ...style }}>
      <span
        style={{
          position: "absolute",
          left: -10,
          right: -10,
          top: "18%",
          bottom: "8%",
          borderRadius: 14,
          background: A(theme.colors.accent, 0.28),
          transformOrigin: "left center",
          transform: `scaleX(${p})`,
        }}
      />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** stroke-draw SVG path (pathLength normalised to 1) */
export const DrawPath: React.FC<{ d: string; progress: number; color: string; width?: number; opacity?: number; dash?: boolean }> = ({
  d,
  progress,
  color,
  width = 4,
  opacity = 1,
  dash = false,
}) => (
  <path
    d={d}
    pathLength={1}
    fill="none"
    stroke={color}
    strokeWidth={width}
    strokeLinecap="round"
    strokeLinejoin="round"
    opacity={opacity}
    strokeDasharray={dash ? "0.012 0.014" : 1}
    strokeDashoffset={dash ? 0 : 1 - progress}
  />
);

export type IconName = "crown" | "road" | "town" | "fort" | "ship" | "shield" | "scroll" | "check" | "cross";

const ICONS: Record<IconName, string[]> = {
  crown: ["M8 46 L12 20 L26 34 L32 14 L38 34 L52 20 L56 46 Z", "M8 54 H56"],
  road: ["M24 58 L29 6", "M40 58 L35 6", "M32 52 V44", "M32 36 V28", "M32 20 V12"],
  town: ["M6 52 V32 L18 22 L30 32 V52 Z", "M30 52 V38 L42 28 L56 38 V52 Z", "M4 54 H60"],
  fort: ["M10 54 V22 H20 V30 H26 V22 H38 V30 H44 V22 H54 V54 Z", "M26 54 V42 A6 6 0 0 1 38 42 V54"],
  ship: ["M6 38 H58 L50 52 H14 Z", "M32 38 V8", "M32 10 L52 32 H32", "M6 38 Q3 30 9 26"],
  shield: ["M32 8 L52 16 V32 C52 44 44 52 32 58 C20 52 12 44 12 32 V16 Z"],
  scroll: ["M16 8 H42 L50 16 V56 H16 Z", "M42 8 V16 H50", "M24 28 H42", "M24 38 H42", "M24 48 H36"],
  check: ["M12 34 L26 48 L52 16"],
  cross: ["M16 16 L48 48", "M48 16 L16 48"],
};

export const Icon: React.FC<{ name: IconName; size: number; color?: string; at?: number; width?: number; style?: React.CSSProperties }> = ({
  name,
  size,
  color = theme.colors.accent,
  at = 0,
  width = 3.4,
  style,
}) => {
  const p = useProgress(at, at + 22);
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={style}>
      {ICONS[name].map((d, i) => (
        <DrawPath key={i} d={d} progress={Math.min(1, p * 1.15 - i * 0.04)} color={color} width={width} />
      ))}
    </svg>
  );
};

/** chapter badge: "অধ্যায় ০১" (the only hero-filled element on its frame) + English label */
export const ChapterBadge: React.FC<{ n: string; en: string; at: number }> = ({ n, en, at }) => (
  <Pop at={at} dir="right" dist={30}>
    <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
      <Pill tone="hero" size={34}>
        অধ্যায় {n}
      </Pill>
      <span
        style={{
          fontFamily: theme.fonts.body,
          fontSize: 30,
          fontWeight: theme.weight.strong,
          color: theme.colors.textDim,
          letterSpacing: 0,
          textTransform: "uppercase",
        }}
      >
        {en}
      </span>
    </div>
  </Pop>
);

/** small English sub-label (technical terms / proper names stay in English) */
export const Sub: React.FC<{ children: React.ReactNode; size?: number; color?: string; style?: React.CSSProperties }> = ({
  children,
  size = 30,
  color = theme.colors.textDim,
  style,
}) => (
  <div style={{ fontFamily: theme.fonts.body, fontSize: size, fontWeight: theme.weight.body, color, lineHeight: 1.3, letterSpacing: 0, ...style }}>
    {children}
  </div>
);

/** fast exit (~10 frames) for a block that should leave mid-scene */
export const Out: React.FC<{ at: number; dir?: "left" | "up" | "none"; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  at,
  dir = "left",
  style,
  children,
}) => {
  const p = useProgress(at, at + theme.motion.exit, theme.ease.in);
  const dx = dir === "left" ? -p * 140 : 0;
  const dy = dir === "up" ? -p * 60 : 0;
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        opacity: 1 - p,
        transform: `translate(${dx}px, ${dy}px) scale(${1 - p * 0.03})`,
        pointerEvents: "none",
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** scene wrapper applying the exit (faster than entrance, ~10 frames) */
export const SceneShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const p = interpolate(frame, [durationInFrames - theme.motion.exit, durationInFrames - 1], [0, 1], {
    easing: theme.ease.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        opacity: 1 - p,
        transform: `translateY(${-p * 26}px) scale(${1 - p * 0.012})`,
      }}
    >
      {children}
    </div>
  );
};
