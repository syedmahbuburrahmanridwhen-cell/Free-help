// Global layers: background mesh (below), colour grade + grain + vignette (above), plus the
// chapter rail and the scene-to-scene wipe. Scenes sit between the two layers.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme, A } from "../theme";
import { chapters, scenes, sceneOf } from "../timing";
import { Pill } from "./kit";

export const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 90) * 60;
  const d2 = Math.cos(frame / 110) * 50;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${c.bg}, ${c.bgAlt})` }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -600, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${A(c.surfaceHi, 0.55)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
          bottom: -520, right: -300 - d2, filter: "blur(80px)",
          background: `radial-gradient(circle, ${A(c.hero, 0.16)}, transparent 65%)`,
        }}
      />
      <div
        style={{
          position: "absolute", inset: 0,
          backgroundImage: `linear-gradient(${A(c.text, 0.035)} 1px, transparent 1px), linear-gradient(90deg, ${A(c.text, 0.035)} 1px, transparent 1px)`,
          backgroundSize: "96px 96px",
        }}
      />
    </AbsoluteFill>
  );
};

export const Finish: React.FC = () => {
  const frame = useCurrentFrame();
  const c = theme.colors;
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <>
      {/* grade */}
      <AbsoluteFill style={{ pointerEvents: "none", backgroundColor: c.hero, mixBlendMode: "soft-light", opacity: 0.12 }} />
      <AbsoluteFill
        style={{
          pointerEvents: "none",
          background: `linear-gradient(180deg, ${A(c.black, 0.12)}, transparent 26%, transparent 74%, ${A(c.black, 0.22)})`,
        }}
      />
      {/* grain */}
      <AbsoluteFill
        style={{
          pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
          backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
          opacity: 0.05, mixBlendMode: "overlay",
        }}
      />
      {/* vignette */}
      <AbsoluteFill
        style={{ pointerEvents: "none", background: `radial-gradient(ellipse at center, transparent 56%, ${A(c.black, 0.32)} 100%)` }}
      />
    </>
  );
};

/** crimson wipe whose widest point (full cover) sits exactly on the scene boundary frame */
export const Wipes: React.FC = () => {
  const frame = useCurrentFrame();
  const c = theme.colors;
  return (
    <>
      {scenes.slice(1).map((s) => {
        const p = interpolate(frame, [s.start - 8, s.start + 8], [0, 1], {
          easing: theme.ease.inOut,
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });
        if (p <= 0 || p >= 1) return null;
        const x = interpolate(p, [0, 1], [-135, 135]);
        return (
          <AbsoluteFill key={s.id} style={{ overflow: "hidden", pointerEvents: "none" }}>
            <div
              style={{
                position: "absolute", top: -60, bottom: -60, width: "130%", left: "-15%",
                transform: `translateX(${x}%) skewX(-12deg)`,
                background: `linear-gradient(90deg, ${c.bg} 0%, ${c.hero} 46%, ${c.hero} 54%, ${c.bg} 100%)`,
                borderLeft: `6px solid ${c.accent}`,
                borderRight: `6px solid ${c.accent}`,
                filter: "blur(1.5px)",
              }}
            />
          </AbsoluteFill>
        );
      })}
    </>
  );
};

/** 5 small chapter pills, top-right; current one lit */
export const ChapterRail: React.FC = () => {
  const frame = useCurrentFrame();
  const first = sceneOf("early").start;
  if (frame < first) return null;
  let cur = -1;
  chapters.forEach((ch, i) => {
    if (frame >= sceneOf(ch.scene).start) cur = i;
  });
  const o = interpolate(frame, [first + 10, first + 28], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", top: 54, right: 96, display: "flex", gap: 10, alignItems: "center", opacity: o }}>
      {chapters.map((ch, i) => (
        <Pill key={ch.n} tone={i === cur ? "accent" : "dim"} size={22} style={{ opacity: i === cur ? 1 : i < cur ? 0.7 : 0.4 }}>
          {ch.n}
        </Pill>
      ))}
    </div>
  );
};
