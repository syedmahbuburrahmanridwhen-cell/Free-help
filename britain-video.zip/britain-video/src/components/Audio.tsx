import React from "react";
import { Audio, Sequence, getRemotionEnvironment, getStaticFiles, staticFile } from "remotion";
import { CONFIG } from "../config";
import { SfxEvent } from "../timing";

/** Voice-over preview. Plays public/voiceover.mp3 if present; silently skipped if not.
 *  Studio: controlled by CONFIG.voiceoverInStudio. Render: controlled by CONFIG.voiceoverInRender (default off). */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const wanted = env.isStudio ? CONFIG.voiceoverInStudio : CONFIG.voiceoverInRender;
  if (!wanted) return null;
  let present = true;
  try {
    const files = getStaticFiles();
    // getStaticFiles() can be empty outside Studio — only trust a non-empty listing
    if (files.length > 0) present = files.some((f) => f.name === "voiceover.mp3");
  } catch {
    present = true;
  }
  if (!present) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};

/** SFX layer — one <Audio> per event, placed on the timeline (audible in Studio preview and in render). */
export const SfxLayer: React.FC<{ events: SfxEvent[] }> = ({ events }) => {
  if (!CONFIG.sfx) return null;
  return (
    <>
      {events.map((e, i) => (
        <Sequence key={i} from={Math.max(0, e.at)} durationInFrames={60} layout="none">
          <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.vol} playbackRate={e.rate ?? 1} />
        </Sequence>
      ))}
    </>
  );
};
