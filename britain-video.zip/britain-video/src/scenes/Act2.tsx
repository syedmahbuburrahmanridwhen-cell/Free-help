// Act 2 — rise of England (1066), Wales, birth of Great Britain, Scotland & James (cues 21–39, 0:46–1:31)
import React from "react";
import { interpolateColors, useCurrentFrame } from "remotion";
import { theme, A } from "../theme";
import { local, t, tIn, SfxEvent } from "../timing";
import { ChapterBadge, Counter, DrawPath, Float, Glass, Icon, Out, Pill, Pop, Sub, Words, useProgress, useSpring } from "../components/kit";
import { IslandMap, REGION_CENTER, mapPt, viewOf } from "../components/IslandMap";
import { Abs } from "./util";

const c = theme.colors;
const GB = viewOf(["scotland", "england", "wales"], 10);

const Card: React.FC<{ bn: string; en: string; icon: "ship" | "cross" | "shield" | "crown" | "scroll"; at: number; w?: number; tone?: "gold" | "dim" }> = ({
  bn, en, icon, at, w = 700, tone = "gold",
}) => (
  <Pop at={at} dir="left" dist={50} cfg="snappy">
    <Glass style={{ width: w, padding: "24px 34px", display: "flex", alignItems: "center", gap: 26 }}>
      <Icon name={icon} size={72} at={at + 3} color={tone === "gold" ? c.accent : c.textDim} />
      <div>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 50, lineHeight: theme.lineHeight, color: c.text }}>{bn}</div>
        <Sub size={28}>{en}</Sub>
      </div>
    </Glass>
  </Pop>
);

/* ───────────────────────── 6 · THE RISE OF ENGLAND + 1066 (Chapter → Data counter) ───────────────────────── */
const Ri = local("rise");
export const Rise: React.FC = () => {
  const tr = Ri.b(tIn(23, 0.55));
  const wAt = Ri.b(tIn(23, 0.82));
  const nAt = Ri.b(t(25));
  const hAt = Ri.b(tIn(25, 0.4));
  const hasAt = Ri.b(t(26));
  const normAt = Ri.b(tIn(26, 0.55));
  const foreAt = Ri.b(t(27));
  const dim = useProgress(foreAt - 3, foreAt + 10);
  const glow = useSpring(6, "smooth");
  const arrow = useProgress(nAt + 4, nAt + 26);
  return (
    <>
      {/* Phase A — chapter title */}
      <Out at={tr - 2}>
        <Abs x={120} y={150}><ChapterBadge n="০২" en="The rise of England" at={4} /></Abs>
        <Abs x={120} y={270} w={900}><Words text="ইংল্যান্ডের উত্থান" at={10} size={170} per={6} hi={[1]} /></Abs>
        <Abs x={1130} y={150}>
          <Float amp={7}>
            <IslandMap
              h={780}
              view={undefined}
              regions={{
                scotland: { fillOp: 0.5 },
                england: { fill: c.hero, glow: A(c.hero, 0.5 * glow), stroke: c.text, strokeW: 3.5, scale: 1 + 0.03 * glow },
                wales: { fillOp: 0.5 },
              }}
            />
          </Float>
        </Abs>
      </Out>
      {/* Phase B — 1066 */}
      <div style={{ position: "absolute", inset: 0, opacity: 1 - dim * 0.88, filter: `blur(${dim * 8}px)` }}>
        <Abs x={120} y={140}>
          <Pop at={tr} dir="up" from={0.85}><Counter to={1066} from={760} at={tr + 2} size={310} /></Pop>
        </Abs>
        <Abs x={120} y={500}>
          <Pop at={hasAt} dir="up" cfg="snappy">
            <Glass style={{ width: 760, padding: "30px 40px", display: "flex", alignItems: "center", gap: 28 }}>
              <Icon name="shield" size={92} at={hasAt + 3} />
              <div>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 60, lineHeight: theme.lineHeight, color: c.text }}>হেস্টিংসের যুদ্ধ</div>
                <Sub size={30}>Battle of Hastings</Sub>
              </div>
            </Glass>
          </Pop>
        </Abs>
        <Abs x={120} y={760}><Pop at={normAt} dir="up" cfg="bouncy"><Pill tone="hero" size={46}>নরম্যান বিজয়</Pill></Pop></Abs>
        <Abs x={1000} y={150}><Card bn="উইলিয়াম দ্য কনকারার" en="William the Conqueror" icon="ship" at={wAt} w={800} /></Abs>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <DrawPath d="M1160 470 H1640" progress={arrow} color={c.accent} width={5} />
          <g opacity={arrow}><path d="M1620 450 L1646 470 L1620 490" fill="none" stroke={c.accent} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" /></g>
        </svg>
        <Abs x={1000} y={420}><Pop at={nAt} dir="right" cfg="snappy"><Pill tone="accent" size={36}>নরম্যান্ডি</Pill></Pop></Abs>
        <Abs x={1670} y={420}><Pop at={nAt + 8} dir="left" cfg="snappy"><Pill tone="dim" size={36}>ইংল্যান্ড</Pill></Pop></Abs>
        <Abs x={1000} y={580}><Card bn="রাজা হ্যারল্ড" en="King Harold · defeated" icon="cross" at={hAt} w={800} tone="dim" /></Abs>
      </div>
      {/* "changed England forever" */}
      <Abs x={160} y={360} w={1600}>
        <Pop at={foreAt} dir="up" cfg="bouncy" from={0.85}>
          <Glass style={{ padding: "50px 60px", textAlign: "center" }}>
            <Words text="চিরতরে বদলে গেল ইংল্যান্ড" at={foreAt + 4} size={120} per={5} align="center" hi={[0]} />
          </Glass>
        </Pop>
      </Abs>
    </>
  );
};
export const riseSfx = (): SfxEvent[] => [
  { at: Ri.S.start + 8, name: "pop", vol: 0.24 },
  { at: Ri.S.start + Ri.b(tIn(23, 0.55)) + 2, name: "tick", vol: 0.2 },
  { at: Ri.S.start + Ri.b(tIn(23, 0.82)), name: "pop", vol: 0.24 },
  { at: Ri.S.start + Ri.b(t(25)), name: "click", vol: 0.2 },
  { at: Ri.S.start + Ri.b(tIn(25, 0.4)), name: "pop", vol: 0.24, rate: 0.94 },
  { at: Ri.S.start + Ri.b(t(26)), name: "pop", vol: 0.26, rate: 1.05 },
  { at: Ri.S.start + Ri.b(t(27)), name: "thud", vol: 0.26 },
];

/* ───────────────────────── 7 · WALES (Process Flow + radiating influence) ───────────────────────── */
const W = local("wales");
export const Wales: React.FC = () => {
  const frame = useCurrentFrame();
  const infAt = W.b(t(28));
  const walAt = W.b(t(29)) + 12;
  const ctrlAt = W.b(t(30));
  const formAt = W.b(t(31));
  const ctrl = useProgress(ctrlAt, ctrlAt + 40, theme.ease.inOut);
  const bar = useProgress(ctrlAt + 6, ctrlAt + 50, theme.ease.inOut);
  const wFill = interpolateColors(ctrl, [0, 1], [A(c.accent, 0.7), A(c.hero, 0.8)]);
  const mapH = 780, left = 150, top = 150;
  const [ex, ey] = mapPt(mapH, left, top, REGION_CENTER.england[0], REGION_CENTER.england[1], viewOf(["scotland", "england", "wales"], 10));
  const steps = [
    { at: infAt, y: 160, bn: "ইংল্যান্ডের প্রভাব বিস্তার", en: "England expanded its influence", icon: "crown" as const },
    { at: walAt, y: 400, bn: "ওয়েলস ধীরে ধীরে ইংরেজ নিয়ন্ত্রণে", en: "Wales brought under English control", icon: "shield" as const },
    { at: formAt, y: 640, bn: "আনুষ্ঠানিক অন্তর্ভুক্তি", en: "Formally incorporated", icon: "scroll" as const },
  ];
  return (
    <>
      {[0, 1, 2].map((i) => {
        const k = frame - infAt - i * 16;
        if (k < 0) return null;
        const p = (k % 54) / 54;
        const r = 70 + p * 340;
        return (
          <div key={i} style={{ position: "absolute", left: ex - r, top: ey - r, width: r * 2, height: r * 2, borderRadius: "50%", border: `3px solid ${A(c.accent, 0.5 * (1 - p))}` }} />
        );
      })}
      <Abs x={left} y={top}>
        <Float amp={5}>
          <IslandMap
            h={mapH}
            view={GB}
            regions={{
              scotland: { fillOp: 0.5 },
              england: { fill: c.surfaceHi, stroke: c.accent, strokeW: 3.5, glow: A(c.accent, 0.25) },
              wales: { fill: wFill, stroke: c.accent, strokeW: 3, scale: 1 + 0.06 * useSpring(walAt, "bouncy") * (1 - ctrl) },
            }}
          />
        </Float>
      </Abs>
      {steps.map((s, i) => (
        <Abs key={s.bn} x={880} y={s.y}>
          <Pop at={s.at} dir="left" dist={60} cfg="snappy">
            <Glass style={{ width: 900, height: 200, padding: "0 40px", display: "flex", alignItems: "center", gap: 30 }}>
              <div style={{ width: 70, height: 70, borderRadius: "50%", border: `3px solid ${A(c.accent, 0.7)}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 38, color: c.accent, lineHeight: 1.2 }}>{i + 1}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 46, lineHeight: theme.lineHeight, color: c.text }}>{s.bn}</div>
                <Sub size={28}>{s.en}</Sub>
                {i === 1 && (
                  <div style={{ marginTop: 10, height: 10, borderRadius: 6, background: A(c.text, 0.12), overflow: "hidden" }}>
                    <div style={{ width: `${bar * 100}%`, height: "100%", background: c.accent, borderRadius: 6 }} />
                  </div>
                )}
              </div>
              <Icon name={s.icon} size={72} at={s.at + 3} />
            </Glass>
          </Pop>
        </Abs>
      ))}
    </>
  );
};
export const walesSfx = (): SfxEvent[] => [
  { at: W.S.start + W.b(t(28)), name: "pop", vol: 0.24 },
  { at: W.S.start + W.b(t(29)) + 12, name: "pop", vol: 0.24, rate: 1.05 },
  { at: W.S.start + W.b(t(30)), name: "click", vol: 0.2 },
  { at: W.S.start + W.b(t(31)), name: "pop", vol: 0.26, rate: 0.95 },
];

/* ───────────────────────── 8 · 1536 / 1543 → THE BIRTH OF GREAT BRITAIN ───────────────────────── */
const Bi = local("birth");
export const Birth: React.FC = () => {
  const a = Bi.b(t(32)) + 2;
  const y1 = Bi.b(tIn(32, 0.3));
  const y2 = Bi.b(tIn(32, 0.52));
  const tr = Bi.b(tIn(32, 0.78));
  const asm = useProgress(tr + 6, tr + 46);
  const fly = (dx: number, dy: number) => ({ dx: dx * (1 - asm), dy: dy * (1 - asm), op: asm > 0 ? Math.min(1, asm * 2) : 0 });
  return (
    <>
      <Out at={tr - 2} dir="up">
        <Abs x={0} y={150} w={1920}><Pop at={a} dir="down" style={{ textAlign: "center" }}><Pill tone="accent" size={40}>আইন · Laws passed</Pill></Pop></Abs>
        {[{ y: 1536, at: y1, x: 250 }, { y: 1543, at: y2, x: 1010 }].map((it) => (
          <Abs key={it.y} x={it.x} y={290}>
            <Pop at={it.at} dir="up" cfg="snappy">
              <Glass style={{ width: 660, height: 440, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
                <Icon name="scroll" size={96} at={it.at + 3} />
                <Counter to={it.y} from={it.y - 220} at={it.at + 2} size={190} />
              </Glass>
            </Pop>
          </Abs>
        ))}
      </Out>
      <Abs x={120} y={150}><ChapterBadge n="০৩" en="The birth of Great Britain" at={tr} /></Abs>
      <Abs x={120} y={270} w={940}><Words text="গ্রেট ব্রিটেনের জন্ম" at={tr + 6} size={160} per={6} hi={[0, 1]} /></Abs>
      <Abs x={1180} y={170}>
        <IslandMap
          h={720}
          view={GB}
          regions={{
            scotland: { ...fly(0, -120), fill: c.surfaceHi },
            england: { ...fly(120, 40), fill: c.surfaceHi },
            wales: { ...fly(-140, 40), fill: c.surfaceHi },
          }}
        />
      </Abs>
    </>
  );
};
export const birthSfx = (): SfxEvent[] => [
  { at: Bi.S.start + Bi.b(t(32)) + 2, name: "pop", vol: 0.22 },
  { at: Bi.S.start + Bi.b(tIn(32, 0.3)), name: "tick", vol: 0.2 },
  { at: Bi.S.start + Bi.b(tIn(32, 0.52)), name: "tick", vol: 0.2, rate: 1.06 },
  { at: Bi.S.start + Bi.b(tIn(32, 0.78)), name: "pop", vol: 0.26 },
  { at: Bi.S.start + Bi.b(t(33)) + 10, name: "chime", vol: 0.24 },
];

/* ───────────────────────── 9 · SCOTLAND & KING JAMES (Glass cards + flip) ───────────────────────── */
const Sc = local("scotland");
export const Scotland: React.FC = () => {
  const sAt = Sc.b(t(34));
  const yAt = Sc.b(tIn(35, 0.5));
  const xAt = Sc.b(t(36));
  const j6 = Sc.b(t(37));
  const thr = Sc.b(tIn(38, 0.2));
  const flipAt = Sc.b(t(39));
  const flip = useProgress(flipAt, flipAt + 22, theme.ease.inOut);
  const lit = useSpring(sAt, "smooth");
  const face: React.CSSProperties = { position: "absolute", inset: 0, backfaceVisibility: "hidden", display: "flex", alignItems: "center", gap: 26, padding: "0 40px" };
  return (
    <>
      <Abs x={140} y={150}>
        <Float amp={5}>
          <IslandMap
            h={800}
            view={GB}
            regions={{
              scotland: { fill: c.accent, fillOp: 0.55 * lit + 0.1, stroke: c.accent, strokeW: 4, glow: A(c.accent, 0.4 * lit) },
              england: { fillOp: 0.5 },
              wales: { fillOp: 0.5 },
            }}
          />
        </Float>
      </Abs>
      <Abs x={880} y={130}><Pop at={sAt} dir="left" cfg="snappy"><Pill tone="accent" size={38}>স্কটল্যান্ড · স্বাধীন রাজ্য</Pill></Pop></Abs>
      <Abs x={880} y={225}><Pop at={yAt} dir="up" from={0.85}><Counter to={1603} from={1300} at={yAt + 2} size={210} /></Pop></Abs>
      <Abs x={880} y={470} w={900}><Words text="অসাধারণ এক ঘটনা!" at={xAt} size={84} per={5} hi={[0]} /></Abs>
      {/* James VI → James I */}
      <Abs x={880} y={650}>
        <Pop at={j6} dir="up" cfg="snappy">
          <div style={{ position: "relative", width: 900, height: 270, perspective: 1400 }}>
            <div style={{ position: "absolute", inset: 0, transformStyle: "preserve-3d", transform: `rotateY(${flip * 180}deg)` }}>
              <Glass style={{ ...face, width: 900, height: 270 }}>
                <Icon name="crown" size={88} at={j6 + 3} />
                <div>
                  <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 58, lineHeight: theme.lineHeight, color: c.text }}>রাজা জেমস VI</div>
                  <Sub size={30}>King James VI of Scotland</Sub>
                </div>
              </Glass>
              <Glass style={{ ...face, width: 900, height: 270, transform: "rotateY(180deg)", borderColor: A(c.accent, 0.7) }}>
                <Icon name="crown" size={88} at={flipAt + 8} />
                <div>
                  <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 58, lineHeight: theme.lineHeight, color: c.accent }}>রাজা জেমস I</div>
                  <Sub size={30}>King James I of England</Sub>
                </div>
              </Glass>
            </div>
          </div>
        </Pop>
      </Abs>
      <Abs x={1230} y={945}><Pop at={thr} dir="up" cfg="snappy" style={{ textAlign: "center" }}><Pill tone="dim" size={30}>ইংরেজ সিংহাসন · English throne</Pill></Pop></Abs>
    </>
  );
};
export const scotlandSfx = (): SfxEvent[] => [
  { at: Sc.S.start + Sc.b(t(34)), name: "pop", vol: 0.24 },
  { at: Sc.S.start + Sc.b(tIn(35, 0.5)) + 2, name: "tick", vol: 0.2 },
  { at: Sc.S.start + Sc.b(t(36)), name: "pop", vol: 0.24, rate: 1.05 },
  { at: Sc.S.start + Sc.b(t(37)), name: "pop", vol: 0.26 },
  { at: Sc.S.start + Sc.b(tIn(38, 0.2)), name: "click", vol: 0.2 },
  { at: Sc.S.start + Sc.b(t(39)), name: "chime", vol: 0.26 },
];
