// Act 3 — union of crowns, 1707, 1801, 1922, final reveal, recap (cues 40–60, 1:31–2:20)
import React from "react";
import { theme, A } from "../theme";
import { local, t, tIn, SfxEvent } from "../timing";
import { ChapterBadge, Counter, DrawPath, Float, Glass, Icon, Out, Pill, Pop, Sub, Words, useProgress, useSpring } from "../components/kit";
import { IslandMap, REGION_CENTER, RegionKey, RegionStyle, mapPt, viewOf } from "../components/IslandMap";
import { Abs } from "./util";

const c = theme.colors;
const GB = viewOf(["scotland", "england", "wales"], 10);
const UKV = viewOf(["scotland", "england", "wales", "ni"], 10);
const IRV = viewOf(["scotland", "england", "wales", "ni", "ireland"], 10);

/* ───────────────────────── 10 · SHARED CROWN → ACTS OF UNION ───────────────────────── */
const Un = local("union");
export const Union: React.FC = () => {
  const mAt = Un.b(t(40));
  const crownAt = Un.b(tIn(40, 0.25));
  const sepAt = Un.b(t(41));
  const tr = Un.b(t(42));
  const sep = useProgress(sepAt, sepAt + 24);
  const asm = useProgress(tr + 8, tr + 50);
  const join = useProgress(Un.b(t(44)), Un.b(t(44)) + 26);
  const gbAt = Un.b(t(45));
  const fly = (dx: number, dy: number) => ({ dx: dx * (1 - asm), dy: dy * (1 - asm), op: Math.min(1, asm * 2.2) });
  const mapH = 760, left = 1010, top = 150;
  const [sx, sy] = mapPt(mapH, left, top, REGION_CENTER.scotland[0], REGION_CENTER.scotland[1], GB);
  const [ex, ey] = mapPt(mapH, left, top, REGION_CENTER.england[0], REGION_CENTER.england[1], GB);
  const lit = A(c.accent, 0.9);
  return (
    <>
      {/* Phase A — one monarch, two countries */}
      <Out at={tr - 2} dir="up">
        <Abs x={0} y={130} w={1920}><Pop at={mAt} dir="down" style={{ textAlign: "center" }}><Pill tone="accent" size={42}>একই রাজা</Pill></Pop></Abs>
        <Abs x={730} y={310}>
          <Pop at={mAt + 4} dir="right" cfg="smooth">
            <div style={{ width: 460, height: 460, borderRadius: "50%", background: `radial-gradient(circle at 40% 35%, ${A(c.surfaceHi, 0.9)}, ${A(c.surface, 0.9)})`, border: `2px solid ${A(c.text, 0.25)}`, display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: 110, paddingRight: 90 }}>
              <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 60, lineHeight: theme.lineHeight, color: c.text }}>স্কটল্যান্ড</div>
            </div>
          </Pop>
        </Abs>
        <Abs x={1000} y={310}>
          <Pop at={mAt + 8} dir="left" cfg="smooth">
            <div style={{ width: 460, height: 460, borderRadius: "50%", background: `radial-gradient(circle at 60% 35%, ${A(c.surfaceHi, 0.9)}, ${A(c.surface, 0.9)})`, border: `2px solid ${A(c.text, 0.25)}`, display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: 110, paddingLeft: 90 }}>
              <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 60, lineHeight: theme.lineHeight, color: c.text }}>ইংল্যান্ড</div>
            </div>
          </Pop>
        </Abs>
        <Abs x={908} y={496}><Pop at={crownAt} dir="down" cfg="bouncy"><Icon name="crown" size={104} at={crownAt + 3} /></Pop></Abs>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <DrawPath d="M960 390 V470" progress={sep} color={A(c.text, 0.55)} width={3} dash />
          <DrawPath d="M960 610 V780" progress={sep} color={A(c.text, 0.55)} width={3} dash />
        </svg>
        <Abs x={0} y={870} w={1920}><Pop at={sepAt} dir="up" style={{ textAlign: "center" }} cfg="snappy"><Pill tone="dim" size={42}>তবুও আলাদা দেশ</Pill></Pop></Abs>
      </Out>
      {/* Phase B — 1707 */}
      <Abs x={120} y={150}>
        <Pop at={tr} dir="up" from={0.85}><Counter to={1707} from={1400} at={tr + 2} size={250} /></Pop>
      </Abs>
      <Abs x={120} y={450}>
        <Pop at={tr + 8} dir="up" cfg="snappy">
          <Glass style={{ display: "flex", alignItems: "center", gap: 24, padding: "22px 36px" }}>
            <Icon name="scroll" size={70} at={tr + 10} />
            <div>
              <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 48, lineHeight: theme.lineHeight, color: c.text }}>Acts of Union</div>
              <Sub size={28}>রাজনৈতিকভাবে এক হলো ইংল্যান্ড ও স্কটল্যান্ড</Sub>
            </div>
          </Glass>
        </Pop>
      </Abs>
      <Abs x={120} y={700} w={800}>
        <Words text="গ্রেট ব্রিটেন" at={gbAt} size={140} per={6} hi={[0, 1]} />
      </Abs>
      <Abs x={left} y={top}>
        <Float amp={5}>
          <IslandMap
            h={mapH}
            view={GB}
            regions={{
              scotland: { ...fly(0, -130), fill: c.surfaceHi, stroke: join > 0.1 ? lit : A(c.text, 0.55), glow: A(c.accent, 0.35 * join) },
              england: { ...fly(130, 50), fill: c.surfaceHi, stroke: join > 0.1 ? lit : A(c.text, 0.55), glow: A(c.accent, 0.35 * join) },
              wales: { ...fly(-150, 40), fill: c.surfaceHi, stroke: join > 0.1 ? lit : A(c.text, 0.55) },
            }}
          />
        </Float>
      </Abs>
      <Abs x={sx - 80} y={sy - 20}><Pop at={Un.b(t(43))} dir="down" cfg="snappy"><Pill tone="dim" size={26}>স্কটল্যান্ড</Pill></Pop></Abs>
      <Abs x={ex - 70} y={ey - 20}><Pop at={Un.b(t(43)) + 8} dir="down" cfg="snappy"><Pill tone="dim" size={26}>ইংল্যান্ড</Pill></Pop></Abs>
    </>
  );
};
export const unionSfx = (): SfxEvent[] => [
  { at: Un.S.start + Un.b(t(40)), name: "pop", vol: 0.24 },
  { at: Un.S.start + Un.b(tIn(40, 0.25)), name: "chime", vol: 0.22 },
  { at: Un.S.start + Un.b(t(41)), name: "click", vol: 0.2 },
  { at: Un.S.start + Un.b(t(42)) + 2, name: "tick", vol: 0.2 },
  { at: Un.S.start + Un.b(t(43)), name: "pop", vol: 0.22 },
  { at: Un.S.start + Un.b(t(45)), name: "chime", vol: 0.28 },
];

/* ───────────────────────── 11 · THE UNITED KINGDOM + 1801 ───────────────────────── */
const K = local("uk1801");
export const UK1801: React.FC = () => {
  const tr = K.b(tIn(46, 0.7));
  const irAt = K.b(t(47));
  const ttlAt = K.b(t(48));
  const asm = useProgress(irAt, irAt + 40, theme.ease.inOut);
  const mapH = 740, left = 1060, top = 150;
  const [gx, gy] = mapPt(mapH, left, top, REGION_CENTER.england[0], REGION_CENTER.england[1], IRV);
  const [ix, iy] = mapPt(mapH, left, top, REGION_CENTER.ni[0], REGION_CENTER.ni[1], IRV);
  const irishFill = A(c.accent, 0.75);
  return (
    <>
      <Out at={tr - 2}>
        <Abs x={120} y={150}><ChapterBadge n="০৪" en="The United Kingdom" at={4} /></Abs>
        <Abs x={120} y={270} w={940}><Words text="যুক্তরাজ্য" at={10} size={210} per={6} hi={[0]} /></Abs>
      </Out>
      <Abs x={120} y={150}>
        <Pop at={tr} dir="up" from={0.85}><Counter to={1801} from={1500} at={tr + 2} size={250} /></Pop>
      </Abs>
      <Abs x={left} y={top}>
        <Float amp={5}>
          <IslandMap
            h={mapH}
            view={IRV}
            regions={{
              scotland: { fill: c.surfaceHi },
              england: { fill: c.surfaceHi },
              wales: { fill: c.surfaceHi },
              ni: { dx: -230 * (1 - asm), fill: irishFill, stroke: c.accent, op: irAt > 0 ? Math.min(1, 0.2 + asm * 2) : 0 },
              ireland: { dx: -230 * (1 - asm), fill: irishFill, stroke: c.accent, op: irAt > 0 ? Math.min(1, 0.2 + asm * 2) : 0 },
            }}
          />
        </Float>
      </Abs>
      <Abs x={gx - 40} y={gy + 30}><Pop at={tr + 6} dir="down" cfg="snappy"><Pill tone="dim" size={28}>গ্রেট ব্রিটেন</Pill></Pop></Abs>
      <Abs x={ix - 70} y={iy - 160}><Pop at={irAt + 4} dir="down" cfg="snappy"><Pill tone="accent" size={28}>আয়ারল্যান্ড</Pill></Pop></Abs>
      <Abs x={120} y={470} w={880}>
        <Pop at={irAt} dir="up" cfg="snappy"><Sub size={40} color={c.text}>গ্রেট ব্রিটেন যুক্ত হলো আয়ারল্যান্ডের সাথে</Sub></Pop>
      </Abs>
      <Abs x={120} y={650} w={900}>
        <Pop at={ttlAt} dir="up" cfg="snappy">
          <Glass style={{ padding: "28px 38px" }}>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 60, lineHeight: theme.lineHeight, color: c.text }}>গ্রেট ব্রিটেন ও আয়ারল্যান্ডের যুক্তরাজ্য</div>
            <Sub size={28}>United Kingdom of Great Britain and Ireland</Sub>
          </Glass>
        </Pop>
      </Abs>
    </>
  );
};
export const uk1801Sfx = (): SfxEvent[] => [
  { at: K.S.start + 8, name: "pop", vol: 0.24 },
  { at: K.S.start + K.b(tIn(46, 0.7)) + 2, name: "tick", vol: 0.2 },
  { at: K.S.start + K.b(t(47)), name: "pop", vol: 0.24, rate: 1.05 },
  { at: K.S.start + K.b(t(48)), name: "chime", vol: 0.26 },
];

/* ───────────────────────── 12 · 1922 (Before/After split on the map) ───────────────────────── */
const Sp = local("split1922");
export const Split1922: React.FC = () => {
  const strAt = Sp.b(t(50));
  const leaveAt = Sp.b(t(51));
  const yAt = Sp.b(t(52));
  const nAt = Sp.b(tIn(52, 0.4));
  const away = useProgress(leaveAt, leaveAt + 36, theme.ease.inOut);
  const glow = useSpring(nAt, "smooth");
  const mapH = 740, left = 1060, top = 150;
  const [nx, ny] = mapPt(mapH, left, top, REGION_CENTER.ni[0], REGION_CENTER.ni[1], IRV);
  return (
    <>
      <Abs x={120} y={140}><Pop at={strAt} dir="right" dist={30}><Pill tone="dim" size={36}>রাজনৈতিক সংগ্রাম</Pill></Pop></Abs>
      <Abs x={120} y={230}><Pop at={yAt} dir="up" from={0.85}><Counter to={1922} from={1600} at={yAt + 2} size={250} /></Pop></Abs>
      <Abs x={120} y={520} w={860}>
        <Pop at={leaveAt} dir="up" cfg="snappy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 52, lineHeight: theme.lineHeight, color: c.text }}>
            আয়ারল্যান্ডের বেশিরভাগ অংশ ছেড়ে গেল
          </div>
          <Sub size={28}>Most of Ireland left the United Kingdom</Sub>
        </Pop>
      </Abs>
      <Abs x={120} y={790}>
        <Pop at={nAt} dir="up" cfg="bouncy">
          <Glass style={{ display: "flex", alignItems: "center", gap: 24, padding: "24px 40px", borderColor: A(c.hero, 0.8) }}>
            <Icon name="check" size={64} at={nAt + 3} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 52, lineHeight: theme.lineHeight, color: c.text }}>উত্তর আয়ারল্যান্ড থেকে গেল</div>
          </Glass>
        </Pop>
      </Abs>
      <Abs x={left} y={top}>
        <Float amp={5}>
          <IslandMap
            h={mapH}
            view={IRV}
            regions={{
              scotland: { fill: c.surfaceHi },
              england: { fill: c.surfaceHi },
              wales: { fill: c.surfaceHi },
              ireland: { dx: -190 * away, dy: 20 * away, rot: -5 * away, op: 1 - 0.55 * away, fill: A(c.accent, 0.75), stroke: c.accent, dashed: away > 0.5 },
              ni: { fill: glow > 0.05 ? c.hero : A(c.accent, 0.75), stroke: glow > 0.05 ? c.text : c.accent, strokeW: 3.5, glow: A(c.hero, 0.55 * glow), scale: 1 + 0.08 * glow },
            }}
          />
        </Float>
      </Abs>
      <Abs x={nx - 175} y={ny - 150}><Pop at={nAt + 6} dir="down" cfg="snappy"><Pill tone="accent" size={28}>Northern Ireland</Pill></Pop></Abs>
    </>
  );
};
export const split1922Sfx = (): SfxEvent[] => [
  { at: Sp.S.start + Sp.b(t(50)), name: "pop", vol: 0.22 },
  { at: Sp.S.start + Sp.b(t(51)), name: "click", vol: 0.2 },
  { at: Sp.S.start + Sp.b(t(52)) + 2, name: "tick", vol: 0.2 },
  { at: Sp.S.start + Sp.b(tIn(52, 0.4)), name: "pop", vol: 0.26, rate: 0.95 },
];

/* ───────────────────────── 13 · THE FINAL REVEAL (Kinetic) ───────────────────────── */
const Rv = local("reveal");
export const Reveal: React.FC = () => {
  const tr = Rv.b(tIn(53, 0.78));
  const fillP = useProgress(tr + 4, tr + 44);
  const outline = useProgress(8, 60);
  const ttl = Rv.b(t(54));
  const sub = Rv.b(t(55));
  const four = Rv.b(t(56));
  const glow = useSpring(tr + 4, "smooth");
  const reg = (fill: string, extra?: object) => ({
    draw: outline,
    fillOp: fillP,
    fill,
    stroke: A(c.accent, 0.5 + 0.5 * fillP),
    glow: A(c.accent, 0.28 * glow),
    ...extra,
  });
  return (
    <>
      <Out at={tr - 2}>
        <Abs x={120} y={150}><ChapterBadge n="০৫" en="The final reveal" at={4} /></Abs>
        <Abs x={120} y={270} w={940}><Words text="চূড়ান্ত উন্মোচন" at={10} size={190} per={6} hi={[1]} /></Abs>
      </Out>
      <Abs x={1100} y={130}>
        <Float amp={7}>
          <IslandMap
            h={820}
            view={UKV}
            regions={{
              scotland: reg(c.surfaceHi),
              england: reg(c.surfaceHi),
              wales: reg(c.surfaceHi),
              ni: reg(c.hero, { glow: A(c.hero, 0.5 * glow) }),
            }}
          />
        </Float>
      </Abs>
      <Abs x={120} y={190} w={900}>
        <Words text="গ্রেট ব্রিটেন ও উত্তর আয়ারল্যান্ডের যুক্তরাজ্য" at={ttl} size={88} per={5} hi={[0, 1]} />
      </Abs>
      <Abs x={120} y={560} w={900}>
        <Pop at={sub} dir="up" cfg="snappy"><Sub size={40} color={c.text}>United Kingdom of Great Britain and Northern Ireland</Sub></Pop>
      </Abs>
      <Abs x={120} y={760}>
        <Pop at={four} dir="up" cfg="bouncy"><Pill tone="accent" size={52}>আজ: চারটি দেশ</Pill></Pop>
      </Abs>
    </>
  );
};
export const revealSfx = (): SfxEvent[] => [
  { at: Rv.S.start + 8, name: "pop", vol: 0.24 },
  { at: Rv.S.start + Rv.b(tIn(53, 0.78)), name: "thud", vol: 0.28 },
  { at: Rv.S.start + Rv.b(t(54)), name: "chime", vol: 0.3 },
  { at: Rv.S.start + Rv.b(t(56)), name: "pop", vol: 0.26 },
];

/* ───────────────────────── 14 · RECAP GRID + CLOSE ───────────────────────── */
const Rc = local("recap");
export const Recap: React.FC = () => {
  const base = Rc.b(t(57)) + 4;
  const cards = [
    { key: "england" as const, bn: "ইংল্যান্ড", en: "England", fill: c.hero },
    { key: "scotland" as const, bn: "স্কটল্যান্ড", en: "Scotland", fill: c.surfaceHi },
    { key: "wales" as const, bn: "ওয়েলস", en: "Wales", fill: c.accent },
    { key: "ni" as const, bn: "উত্তর আয়ারল্যান্ড", en: "Northern Ireland", fill: c.textDim },
  ];
  const histAt = Rc.b(t(59));
  const chips = [Rc.b(t(60)), Rc.b(tIn(60, 0.34)), Rc.b(tIn(60, 0.67))];
  const chipText = ["সংঘাত", "বিজয়", "ঐক্য"];
  const uni = useSpring(chips[2], "smooth");
  return (
    <>
      {cards.map((cd, i) => {
        // equal spacing inside cue 57 (England, Scotland, Wales) and one more beat for Northern Ireland
        const at = Rc.b(t(57)) + 4 + Math.round(i * 28.5);
        return (
          <Abs key={cd.key} x={128 + i * 428} y={130}>
            <Pop at={at} dir="up" cfg="snappy">
              <Glass style={{ width: 380, height: 540, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", padding: "34px 20px 30px" }}>
                <div style={{ height: 300, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Float amp={4} phase={i}>
                    <IslandMap
                      h={cd.key === "ni" ? 170 : cd.key === "wales" ? 230 : 300}
                      view={viewOf([cd.key], 8)}
                      regions={{ [cd.key]: { fill: cd.fill, fillOp: cd.key === "england" ? 0.9 : 0.85, stroke: c.text, strokeW: 3 } } as Partial<Record<RegionKey, RegionStyle>>}
                    />
                  </Float>
                </div>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: cd.key === "ni" ? 46 : 58, lineHeight: theme.lineHeight, color: c.text }}>{cd.bn}</div>
                  <Sub size={30}>{cd.en}</Sub>
                </div>
              </Glass>
            </Pop>
          </Abs>
        );
      })}
      <Abs x={128} y={720} w={1664}>
        <Pop at={histAt} dir="up" cfg="snappy">
          <div style={{ textAlign: "center" }}>
            <Words text="হাজার হাজার বছরের ইতিহাস" at={histAt + 2} size={72} per={5} align="center" />
          </div>
        </Pop>
      </Abs>
      <div style={{ position: "absolute", left: 0, top: 890, width: 1920, display: "flex", justifyContent: "center", gap: 28 }}>
        {chipText.map((tx, i) => (
          <Pop key={tx} at={chips[i]} dir="up" cfg="bouncy">
            <Pill tone={i === 2 ? "hero" : "accent"} size={44} style={i === 2 ? { boxShadow: `0 0 ${40 * uni}px ${A(c.hero, 0.6)}` } : undefined}>
              <Icon name="check" size={40} color={i === 2 ? c.text : c.accent} at={chips[i] + 3} />
              {tx}
            </Pill>
          </Pop>
        ))}
      </div>
    </>
  );
};
export const recapSfx = (): SfxEvent[] => {
  const base = Rc.S.start + Rc.b(t(57)) + 4;
  return [
    ...[0, 1, 2, 3].map((i) => ({ at: base + Math.round(i * 28.5), name: "pop" as const, vol: 0.24, rate: 0.96 + i * 0.03 })),
    { at: Rc.S.start + Rc.b(t(59)), name: "thud" as const, vol: 0.22 },
    { at: Rc.S.start + Rc.b(t(60)), name: "click" as const, vol: 0.2 },
    { at: Rc.S.start + Rc.b(tIn(60, 0.34)), name: "click" as const, vol: 0.2, rate: 1.05 },
    { at: Rc.S.start + Rc.b(tIn(60, 0.67)), name: "chime" as const, vol: 0.28 },
  ];
};
