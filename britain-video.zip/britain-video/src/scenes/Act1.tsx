// Act 1 — hook, before/after, early kingdoms, Romans, the divided island (cues 1–20, 0:00–0:46)
import React from "react";
import { theme, A } from "../theme";
import { local, t, tIn, SfxEvent } from "../timing";
import { ChapterBadge, Counter, DrawPath, Float, Glass, Icon, Pill, Pop, Sub, Sweep, Words, useProgress, useSpring } from "../components/kit";
import { IslandMap, REGION_PTS, inside, mapPt, viewOf } from "../components/IslandMap";
import { Abs, seeded } from "./util";

const c = theme.colors;

/* ───────────────────────── 1 · HOOK (Kinetic Typography) ───────────────────────── */
const H = local("hook");
export const Hook: React.FC = () => {
  const crackAt = H.b(tIn(3, 0.55));
  const draw = useProgress(4, 46);
  const fill = useProgress(34, 70);
  const crack = useProgress(crackAt, crackAt + 22);
  const lat = useProgress(0, 60);
  const reg = (dx: number, dy: number, rot: number) => ({
    draw,
    fillOp: fill,
    dx: dx * crack,
    dy: dy * crack,
    rot: rot * crack,
    stroke: crack > 0.05 ? A(c.accent, 0.4 + 0.5 * crack) : A(c.text, 0.55),
  });
  return (
    <>
      {/* lattice motif: cross + saltire */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <DrawPath d="M1440 40 V1040" progress={lat} color={A(c.accent, 0.22)} width={2} />
        <DrawPath d="M1000 540 H1900" progress={lat} color={A(c.accent, 0.22)} width={2} />
        <DrawPath d="M1050 100 L1830 980" progress={lat} color={A(c.accent, 0.16)} width={2} />
        <DrawPath d="M1830 100 L1050 980" progress={lat} color={A(c.accent, 0.16)} width={2} />
      </svg>
      <Abs x={1130} y={150}>
        <Float amp={7}>
          <IslandMap
            h={780}
            regions={{
              scotland: { ...reg(-10, -22, -2.5) },
              england: { ...reg(8, 10, 1.5), fill: c.surfaceHi },
              wales: { ...reg(-26, 6, -4) },
            }}
          />
        </Float>
      </Abs>
      <Abs x={120} y={128}>
        <Pop at={3} dir="right" dist={30}>
          <Pill tone="accent" size={30}>How Britain Was Formed</Pill>
        </Pop>
      </Abs>
      <Abs x={120} y={205} w={980}>
        <Words text="ব্রিটেন কীভাবে" at={6} size={150} per={5} hi={[0]} />
        <Words text="তৈরি হলো?" at={16} size={150} per={5} />
      </Abs>
      <Abs x={120} y={690}>
        <Pop at={H.b(t(2))} dir="up" cfg="snappy">
          <Glass style={{ display: "flex", alignItems: "center", gap: 26, padding: "26px 40px" }}>
            <Icon name="crown" size={64} at={H.b(t(2)) + 4} />
            <span style={{ fontFamily: theme.fonts.body, fontWeight: theme.weight.strong, fontSize: 48, lineHeight: theme.lineHeight, color: c.text }}>
              বিশ্বের অন্যতম প্রভাবশালী দেশ
            </span>
          </Glass>
        </Pop>
      </Abs>
      <Abs x={120} y={860} w={1000}>
        <Words text="কিন্তু সবসময় এক দেশ ছিল না" at={crackAt} size={66} per={4} hi={[2, 3]} weight={theme.weight.strong} />
      </Abs>
    </>
  );
};
export const hookSfx = (): SfxEvent[] => [
  { at: 8, name: "thud", vol: 0.3 },
  { at: H.S.start + H.b(t(2)), name: "pop", vol: 0.26 },
  { at: H.S.start + H.b(tIn(3, 0.55)), name: "pop", vol: 0.26, rate: 0.94 },
];

/* ───────────────────────── 2 · BEFORE / AFTER SPLIT ───────────────────────── */
const B = local("beforeAfter");
export const BeforeAfter: React.FC = () => {
  const rightAt = B.b(tIn(4, 0.5));
  const splitAt = B.b(t(5));
  const split = useProgress(splitAt, splitAt + 26);
  const qAt = B.b(t(9));
  const dim = useProgress(qAt - 4, qAt + 10);
  const crowns = B.b(t(6));
  const divider = useProgress(rightAt - 4, rightAt + 20);
  const frag = (dx: number, dy: number, rot: number) => ({
    dx: dx * split,
    dy: dy * split,
    rot: rot * split,
    stroke: split > 0.05 ? A(c.accent, 0.9) : A(c.text, 0.55),
    fill: c.surfaceHi,
  });
  const chips: { at: number; icon: "ship" | "shield" | "scroll"; text: string }[] = [
    { at: B.b(t(7)), icon: "ship", text: "আক্রমণ" },
    { at: B.b(tIn(7, 0.6)), icon: "shield", text: "যুদ্ধ" },
    { at: B.b(tIn(8, 0.15)), icon: "scroll", text: "রাজনৈতিক জোট" },
  ];
  return (
    <>
      <div style={{ position: "absolute", inset: 0, opacity: 1 - dim * 0.88, filter: `blur(${dim * 7}px)` }}>
        {/* LEFT — today */}
        <Abs x={120} y={110}>
          <Pop at={4} dir="right" dist={30}>
            <Pill tone="dim" size={34}>আজ</Pill>
          </Pop>
        </Abs>
        <Abs x={120} y={170} w={760}>
          <Words text="একটি ব্রিটেন" at={8} size={84} per={5} />
        </Abs>
        <Abs x={250} y={300}>
          <Float amp={5}>
            <IslandMap h={640} view={viewOf(["scotland", "england", "wales"], 10)} regions={{ scotland: {}, england: {}, wales: {} }} />
          </Float>
        </Abs>
        {/* divider + handle */}
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <DrawPath d="M960 60 V1020" progress={divider} color={A(c.text, 0.28)} width={2} />
          <g opacity={divider}>
            <circle cx={960} cy={540} r={34} fill={c.bg} stroke={c.accent} strokeWidth={3} />
            <path d="M950 540 L942 540 M950 532 L942 540 L950 548 M970 540 L978 540 M970 532 L978 540 L970 548" stroke={c.accent} strokeWidth={3} fill="none" strokeLinecap="round" />
          </g>
        </svg>
        {/* RIGHT — long ago */}
        <Abs x={1040} y={110}>
          <Pop at={rightAt} dir="left" dist={30}>
            <Pill tone="accent" size={34}>শত শত বছর আগে</Pill>
          </Pop>
        </Abs>
        <Abs x={1180} y={190}>
          <IslandMap
            h={600}
            view={viewOf(["scotland", "england", "wales"], 10)}
            regions={{
              scotland: { ...frag(-40, -34, -5), op: useSpring(rightAt, "smooth") },
              england: { ...frag(46, 18, 4), op: useSpring(rightAt, "smooth") },
              wales: { ...frag(-70, 30, -9), op: useSpring(rightAt, "smooth") },
            }}
          />
        </Abs>
        <Abs x={1440} y={220}><Pop at={crowns} dir="down" cfg="bouncy"><Icon name="crown" size={56} at={crowns + 2} /></Pop></Abs>
        <Abs x={1590} y={410}><Pop at={crowns + 5} dir="down" cfg="bouncy"><Icon name="crown" size={56} at={crowns + 7} /></Pop></Abs>
        <Abs x={1100} y={560}><Pop at={crowns + 10} dir="down" cfg="bouncy"><Icon name="crown" size={56} at={crowns + 12} /></Pop></Abs>
        <Abs x={1040} y={820}>
          <Pop at={crowns + 12} dir="up"><Pill tone="hero" size={32}>আলাদা রাজ্য · ভিন্ন শাসক</Pill></Pop>
        </Abs>
        {/* invasions / wars / alliances — one per cue-beat */}
        <div style={{ position: "absolute", left: 1040, top: 920, display: "flex", gap: 18 }}>
          {chips.map((ch) => (
            <Pop key={ch.text} at={ch.at} dir="up" cfg="snappy">
              <Glass style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 22px", borderRadius: theme.radius.chip }}>
                <Icon name={ch.icon} size={42} at={ch.at + 2} />
                <span style={{ fontFamily: theme.fonts.body, fontWeight: theme.weight.strong, fontSize: 34, lineHeight: theme.lineHeight, color: c.text, whiteSpace: "nowrap" }}>{ch.text}</span>
              </Glass>
            </Pop>
          ))}
        </div>
      </div>
      {/* the question */}
      <Abs x={210} y={330} w={1500}>
        <Pop at={qAt} dir="up" cfg="bouncy" from={0.85}>
          <Glass style={{ padding: "56px 70px", textAlign: "center" }}>
            <Words text="কীভাবে হলো আজকের ব্রিটেন?" at={qAt + 4} size={112} per={5} align="center" hi={[3]} />
          </Glass>
        </Pop>
      </Abs>
    </>
  );
};
export const beforeAfterSfx = (): SfxEvent[] => [
  { at: B.S.start + B.b(tIn(4, 0.5)), name: "pop", vol: 0.24 },
  { at: B.S.start + B.b(t(5)), name: "pop", vol: 0.28, rate: 0.92 },
  { at: B.S.start + B.b(t(6)), name: "pop", vol: 0.24, rate: 1.04 },
  { at: B.S.start + B.b(t(7)), name: "click", vol: 0.2 },
  { at: B.S.start + B.b(tIn(7, 0.6)), name: "click", vol: 0.2, rate: 1.06 },
  { at: B.S.start + B.b(tIn(8, 0.15)), name: "click", vol: 0.2, rate: 0.96 },
  { at: B.S.start + B.b(t(9)), name: "thud", vol: 0.24 },
];

/* ───────────────────────── 3 · EARLY KINGDOMS (Statement + settlements) ───────────────────────── */
const E = local("early");
const dots = (() => {
  const r = seeded(77);
  const out: { x: number; y: number }[] = [];
  const polys = [REGION_PTS.scotland, REGION_PTS.england, REGION_PTS.wales];
  let guard = 0;
  while (out.length < 54 && guard++ < 4000) {
    const x = 90 + r() * 280;
    const y = 20 + r() * 550;
    if (polys.some((p) => inside(x, y, p))) out.push({ x, y });
  }
  return out;
})();
export const Early: React.FC = () => {
  const ghost = useProgress(E.b(t(11)), E.b(t(11)) + 24);
  const celtic = E.b(t(12));
  const mapH = 800, mx = 1050, my = 150;
  const view = viewOf(["scotland", "england", "wales"], 10);
  return (
    <>
      <Abs x={120} y={150}><ChapterBadge n="০১" en="The early kingdoms" at={4} /></Abs>
      <Abs x={120} y={270} w={900}>
        <Words text="আদি রাজ্যগুলো" at={10} size={170} per={6} hi={[1]} />
      </Abs>
      <Abs x={120} y={560} w={800}>
        <Pop at={E.b(t(10)) + 24} dir="up"><Sub size={36}>দীর্ঘকাল আগে, একটি ঐক্যবদ্ধ দেশ হওয়ার আগে</Sub></Pop>
      </Abs>
      <Abs x={mx} y={my}>
        <Float amp={6}>
          <IslandMap
            h={mapH}
            view={view}
            regions={{
              scotland: { draw: useProgress(8, 50), fillOp: 0.45 * (1 - ghost * 0.4), dashed: ghost > 0.5 },
              england: { draw: useProgress(14, 56), fillOp: 0.45 * (1 - ghost * 0.4), dashed: ghost > 0.5 },
              wales: { draw: useProgress(20, 62), fillOp: 0.45 * (1 - ghost * 0.4), dashed: ghost > 0.5 },
            }}
          />
        </Float>
        {dots.map((d, i) => {
          const [px, py] = mapPt(mapH, 0, 0, d.x, d.y, view);
          return <Dot key={i} x={px} y={py} at={celtic + i * 1.6} />;
        })}
      </Abs>
      <Abs x={120} y={760}>
        <Pop at={celtic + 6} dir="up" cfg="snappy">
          <Glass style={{ padding: "26px 40px" }}>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 54, lineHeight: theme.lineHeight, color: c.text }}>
              প্রাচীন <Sweep at={celtic + 14}>কেল্টিক</Sweep> জনগোষ্ঠী
            </div>
            <Sub size={30}>Celtic peoples · across the island</Sub>
          </Glass>
        </Pop>
      </Abs>
    </>
  );
};
const Dot: React.FC<{ x: number; y: number; at: number }> = ({ x, y, at }) => {
  const p = useSpring(at, "bouncy");
  return (
    <div
      style={{
        position: "absolute", left: x - 9, top: y - 9, width: 18, height: 18, borderRadius: "50%",
        background: c.accent, opacity: Math.min(1, p * 1.4) * 0.9, transform: `scale(${p})`,
        boxShadow: `0 0 18px ${A(c.accent, 0.55)}`,
      }}
    />
  );
};
export const earlySfx = (): SfxEvent[] => [
  { at: E.S.start + 6, name: "pop", vol: 0.24 },
  { at: E.S.start + E.b(t(12)) + 6, name: "pop", vol: 0.26, rate: 1.05 },
];

/* ───────────────────────── 4 · ROMANS (Timeline / Process Flow) ───────────────────────── */
const R = local("romans");
export const Romans: React.FC = () => {
  const lineP = useProgress(R.b(t(13)) , R.b(t(13)) + 40, theme.ease.inOut);
  const mapAt = R.b(t(14));
  const cardTimes = [R.b(t(15)), R.b(tIn(15, 0.34)), R.b(tIn(15, 0.67))];
  const fall = R.b(t(17));
  const f = useProgress(fall, fall + 18);
  const n2 = R.b(tIn(16, 0.5));
  const cards = [
    { icon: "road" as const, bn: "রাস্তা", en: "Roads" },
    { icon: "town" as const, bn: "শহর", en: "Towns" },
    { icon: "fort" as const, bn: "সামরিক বসতি", en: "Military settlements" },
  ];
  const view = viewOf(["scotland", "england", "wales"], 10);
  const lit = useSpring(mapAt, "smooth");
  return (
    <>
      <Abs x={120} y={120}>
        <Pop at={R.b(t(13)) + 2} dir="up">
          <div style={{ display: "flex", alignItems: "baseline", gap: 18 }}>
            <Counter to={43} from={0} at={R.b(t(13)) + 4} size={200} />
            <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 84, color: c.textDim, lineHeight: 1.1 }}>AD</span>
          </div>
        </Pop>
      </Abs>
      <Abs x={120} y={366}>
        <Pop at={R.b(t(13)) + 12} dir="up"><div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 56, lineHeight: theme.lineHeight, color: c.text }}>রোমান সাম্রাজ্যের আক্রমণ</div></Pop>
        <Pop at={R.b(t(13)) + 18} dir="up"><Sub size={32}>Roman Empire</Sub></Pop>
      </Abs>
      {/* England + Wales lit */}
      <Abs x={1010} y={110}>
        <Float amp={5}>
          <IslandMap
            h={380}
            view={view}
            regions={{
              scotland: { fillOp: 0.5, op: 0.8 },
              england: { fill: c.accent, fillOp: 0.5 * lit + 0.1, stroke: c.accent, glow: A(c.accent, 0.3 * lit) },
              wales: { fill: c.accent, fillOp: 0.5 * lit + 0.1, stroke: c.accent },
            }}
          />
        </Float>
      </Abs>
      <Abs x={1260} y={270}><Pop at={mapAt + 6} dir="left"><Pill tone="accent" size={32}>ইংল্যান্ড ও ওয়েলস</Pill></Pop></Abs>
      {/* timeline */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <DrawPath d="M160 580 H1780" progress={lineP} color={A(c.text, 0.35)} width={4} />
        <Node x={310} at={R.b(t(13)) + 6} />
        <Node x={1560} at={n2} />
      </svg>
      {/* three things the Romans built — equal spacing inside cue 15 */}
      {cards.map((cd, i) => (
        <Abs key={cd.bn} x={160 + i * 340} y={660}>
          <Pop at={cardTimes[i]} dir="up" cfg="snappy">
            <div style={{ opacity: 1 - 0.65 * f, transform: `translateY(${f * 14}px) rotate(${f * (i - 1) * 2.2}deg)`, filter: `grayscale(${f})` }}>
              <Glass style={{ width: 300, height: 250, padding: 28, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                <Icon name={cd.icon} size={84} at={cardTimes[i] + 3} />
                <div>
                  <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 46, lineHeight: theme.lineHeight, color: c.text }}>{cd.bn}</div>
                  <Sub size={26}>{cd.en}</Sub>
                </div>
              </Glass>
            </div>
          </Pop>
        </Abs>
      ))}
      {/* 5th century + collapse */}
      <Abs x={1320} y={430} w={480}>
        <Pop at={n2} dir="up" style={{ textAlign: "center" }}>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 62, lineHeight: theme.lineHeight, color: c.text }}>৫ম শতকের শুরু</div>
        </Pop>
      </Abs>
      <Abs x={1320} y={700} w={480}>
        <Pop at={fall} dir="up" cfg="bouncy" style={{ textAlign: "center" }}>
          <Pill tone="hero" size={46}>রোমান শাসনের পতন</Pill>
        </Pop>
      </Abs>
    </>
  );
};
const Node: React.FC<{ x: number; at: number }> = ({ x, at }) => {
  const p = useSpring(at, "bouncy");
  return (
    <g transform={`translate(${x} 580) scale(${p})`} opacity={Math.min(1, p)}>
      <circle r={22} fill={c.bg} stroke={c.accent} strokeWidth={5} />
      <circle r={9} fill={c.accent} />
    </g>
  );
};
export const romansSfx = (): SfxEvent[] => [
  { at: R.S.start + R.b(t(13)) + 4, name: "tick", vol: 0.2 },
  { at: R.S.start + R.b(t(14)), name: "pop", vol: 0.24 },
  { at: R.S.start + R.b(t(15)), name: "pop", vol: 0.24 },
  { at: R.S.start + R.b(tIn(15, 0.34)), name: "pop", vol: 0.24, rate: 1.05 },
  { at: R.S.start + R.b(tIn(15, 0.67)), name: "pop", vol: 0.24, rate: 0.95 },
  { at: R.S.start + R.b(t(17)), name: "thud", vol: 0.26 },
];

/* ───────────────────────── 5 · THE DIVIDED ISLAND (Hub-and-Spoke) ───────────────────────── */
const U = local("hub");
export const Hub: React.FC = () => {
  const cx = 960, cy = 560;
  const aAt = U.b(tIn(18, 0.55)), vAt = U.b(tIn(19, 0.3)), rAt = U.b(t(20)), hAt = U.b(tIn(20, 0.5));
  const l1 = useProgress(aAt, aAt + 20), l2 = useProgress(vAt, vAt + 20), l3 = useProgress(rAt, rAt + 20);
  const drift = useProgress(U.b(t(18)), U.b(t(18)) + 36);
  const spokes = [
    { at: aAt, x: 120, y: 440, bn: "অ্যাংলো-স্যাক্সন রাজ্য", en: "Anglo-Saxon kingdoms", icon: "crown" as const },
    { at: vAt, x: 1300, y: 440, bn: "ভাইকিং আক্রমণ", en: "Viking invasions", icon: "ship" as const },
    { at: rAt, x: 710, y: 830, bn: "প্রতিদ্বন্দ্বী শাসক", en: "Rival rulers", icon: "shield" as const },
  ];
  return (
    <>
      <Abs x={0} y={96} w={1920}>
        <Words text="বিভক্ত দ্বীপ" at={U.b(t(18)) + 2} size={96} per={6} align="center" hi={[1]} />
      </Abs>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <DrawPath d={`M${cx - 130} ${cy} H620`} progress={l1} color={A(c.accent, 0.6)} width={3} dash />
        <DrawPath d={`M${cx + 130} ${cy} H1300`} progress={l2} color={A(c.accent, 0.6)} width={3} dash />
        <DrawPath d={`M${cx} ${cy + 190} V830`} progress={l3} color={A(c.accent, 0.6)} width={3} dash />
      </svg>
      <Abs x={cx - 170} y={cy - 220}>
        <Float amp={5}>
          <IslandMap
            h={440}
            view={viewOf(["scotland", "england", "wales"], 10)}
            regions={{
              scotland: { dx: -16 * drift, dy: -14 * drift, rot: -3 * drift },
              england: { dx: 12 * drift, dy: 8 * drift, rot: 2 * drift },
              wales: { dx: -20 * drift, dy: 10 * drift, rot: -5 * drift },
            }}
          />
        </Float>
      </Abs>
      {spokes.map((s) => (
        <Abs key={s.bn} x={s.x} y={s.y}>
          <Pop at={s.at} dir="up" cfg="snappy">
            <Glass style={{ width: 500, padding: "26px 34px", display: "flex", alignItems: "center", gap: 26 }}>
              <Icon name={s.icon} size={76} at={s.at + 3} />
              <div>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 44, lineHeight: theme.lineHeight, color: c.text }}>{s.bn}</div>
                <Sub size={28}>{s.en}</Sub>
              </div>
            </Glass>
          </Pop>
        </Abs>
      ))}
      <Abs x={0} y={230} w={1920}>
        <Pop at={hAt} dir="down" style={{ textAlign: "center" }} cfg="bouncy">
          <Pill tone="hero" size={38}>রাজনৈতিক মানচিত্র বদলে গেল</Pill>
        </Pop>
      </Abs>
    </>
  );
};
export const hubSfx = (): SfxEvent[] => [
  { at: U.S.start + U.b(tIn(18, 0.55)), name: "pop", vol: 0.24 },
  { at: U.S.start + U.b(tIn(19, 0.3)), name: "pop", vol: 0.24, rate: 1.05 },
  { at: U.S.start + U.b(t(20)), name: "pop", vol: 0.24, rate: 0.95 },
  { at: U.S.start + U.b(tIn(20, 0.5)), name: "thud", vol: 0.22 },
];
