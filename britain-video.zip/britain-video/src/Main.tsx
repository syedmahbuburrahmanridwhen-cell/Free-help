import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { scenes, SceneId, SfxEvent } from "./timing";
import { Backdrop, ChapterRail, Finish, Wipes } from "./components/Backdrop";
import { SceneShell } from "./components/kit";
import { PreviewAudio, SfxLayer } from "./components/Audio";
import { BeforeAfter, Early, Hook, Hub, Romans, beforeAfterSfx, earlySfx, hookSfx, hubSfx, romansSfx } from "./scenes/Act1";
import { Birth, Rise, Scotland, Wales, birthSfx, riseSfx, scotlandSfx, walesSfx } from "./scenes/Act2";
import { Recap, Reveal, Split1922, UK1801, Union, recapSfx, revealSfx, split1922Sfx, uk1801Sfx, unionSfx } from "./scenes/Act3";

const COMPONENTS: Record<SceneId, React.FC> = {
  hook: Hook, beforeAfter: BeforeAfter, early: Early, romans: Romans, hub: Hub, rise: Rise, wales: Wales,
  birth: Birth, scotland: Scotland, union: Union, uk1801: UK1801, split1922: Split1922, reveal: Reveal, recap: Recap,
};

// smooth whoosh centred just before each wipe's widest point; pitch varies a little each time
const transitionSfx = (): SfxEvent[] =>
  scenes.slice(1).map((s, i) => ({ at: s.start - 10, name: "whoosh", vol: 0.24, rate: [1, 0.94, 1.06][i % 3] }));

const SFX: SfxEvent[] = [
  ...transitionSfx(),
  ...hookSfx(), ...beforeAfterSfx(), ...earlySfx(), ...romansSfx(), ...hubSfx(),
  ...riseSfx(), ...walesSfx(), ...birthSfx(), ...scotlandSfx(),
  ...unionSfx(), ...uk1801Sfx(), ...split1922Sfx(), ...revealSfx(), ...recapSfx(),
];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg, color: theme.colors.text, fontFamily: theme.fonts.body }}>
    <Backdrop />
    {scenes.map((s) => {
      const C = COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.start} durationInFrames={s.dur} name={s.id}>
          <SceneShell>
            <C />
          </SceneShell>
        </Sequence>
      );
    })}
    <ChapterRail />
    <Wipes />
    <Finish />
    <SfxLayer events={SFX} />
    <PreviewAudio />
  </AbsoluteFill>
);
