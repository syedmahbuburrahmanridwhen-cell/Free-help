// timing.ts — the SRT (via src/cues.ts) is the ONLY clock. Nothing here is hand-timed:
// every scene boundary is a cue start, every beat is a cue start (or a fraction inside one).
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** visuals land this many frames BEFORE the matching words */
export const LEAD = 5;

const cue = (n: number) => {
  const c = cues.find((x) => x.n === n);
  if (!c) throw new Error(`cue ${n} not found`);
  return c;
};

/** start of cue n, seconds */
export const t = (n: number) => cue(n).start;
/** end of cue n, seconds */
export const tEnd = (n: number) => cue(n).end;
/** a point `frac` (0..1) of the way through cue n — for words in the middle of a cue */
export const tIn = (n: number, frac: number) => cue(n).start + (cue(n).end - cue(n).start) * frac;

export const frames = (sec: number) => Math.round(sec * FPS);
/** absolute frame at which a visual for the words at `sec` should land */
export const beat = (sec: number) => frames(sec) - LEAD;

/** SRT end + 0.5 s hold */
export const TOTAL = frames(cues[cues.length - 1].end) + 15;

export type SceneId =
  | "hook" | "beforeAfter" | "early" | "romans" | "hub" | "rise" | "wales"
  | "birth" | "scotland" | "union" | "uk1801" | "split1922" | "reveal" | "recap";

// `from` = first cue of the scene; a scene runs until the next scene's first cue.
const defs: { id: SceneId; from: number }[] = [
  { id: "hook", from: 1 },
  { id: "beforeAfter", from: 4 },
  { id: "early", from: 10 },
  { id: "romans", from: 13 },
  { id: "hub", from: 18 },
  { id: "rise", from: 21 },
  { id: "wales", from: 28 },
  { id: "birth", from: 32 },
  { id: "scotland", from: 34 },
  { id: "union", from: 40 },
  { id: "uk1801", from: 46 },
  { id: "split1922", from: 50 },
  { id: "reveal", from: 53 },
  { id: "recap", from: 57 },
];

export const scenes = defs.map((d, i) => {
  const start = i === 0 ? 0 : beat(t(d.from));
  const end = i === defs.length - 1 ? TOTAL : beat(t(defs[i + 1].from));
  return { ...d, start, end, dur: end - start };
});

export const sceneOf = (id: SceneId) => {
  const s = scenes.find((x) => x.id === id);
  if (!s) throw new Error(`scene ${id}`);
  return s;
};

/** local-frame helper for a scene: b(sec) = frame inside the scene where the visual for `sec` lands */
export const local = (id: SceneId) => {
  const s = sceneOf(id);
  return { S: s, b: (sec: number) => beat(sec) - s.start };
};

export type SfxName = "pop" | "click" | "tick" | "whoosh" | "chime" | "thud";
export type SfxEvent = { at: number; name: SfxName; vol: number; rate?: number };

/** chapter rail: which of the 5 chapters is active from which scene */
export const chapters = [
  { scene: "early" as SceneId, n: "০১", bn: "আদি রাজ্য" },
  { scene: "rise" as SceneId, n: "০২", bn: "ইংল্যান্ডের উত্থান" },
  { scene: "birth" as SceneId, n: "০৩", bn: "গ্রেট ব্রিটেনের জন্ম" },
  { scene: "uk1801" as SceneId, n: "০৪", bn: "যুক্তরাজ্য" },
  { scene: "reveal" as SceneId, n: "০৫", bn: "চূড়ান্ত উন্মোচন" },
];
